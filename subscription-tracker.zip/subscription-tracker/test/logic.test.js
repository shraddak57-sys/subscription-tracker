const test = require("node:test");
const assert = require("node:assert");
const { monthlyCost, nextRenewal, daysUntil, totals, key } = require("../logic.js");

const today = new Date(2026, 10, 2); // 2026-11-02

test("normalizes cost to a monthly figure", () => {
  assert.strictEqual(monthlyCost(10, "monthly"), 10);
  assert.strictEqual(monthlyCost(120, "yearly"), 10);
  assert.ok(Math.abs(monthlyCost(12, "weekly") - 52) < 1e-9);
});

test("monthly renewal clamps to the end of short months", () => {
  assert.strictEqual(key(nextRenewal("2026-01-31", "monthly", today)), "2026-11-30");
});

test("weekly renewal lands on the next 7-day step", () => {
  assert.strictEqual(key(nextRenewal("2026-10-20", "weekly", today)), "2026-11-03");
});

test("renewal on today's date counts as today", () => {
  assert.strictEqual(key(nextRenewal("2025-11-02", "yearly", today)), "2026-11-02");
  assert.strictEqual(daysUntil(nextRenewal("2025-11-02", "yearly", today), today), 0);
});

test("future start date is the next renewal", () => {
  assert.strictEqual(key(nextRenewal("2026-12-15", "monthly", today)), "2026-12-15");
});

test("totals sum monthly and yearly cost", () => {
  const t = totals([{ price: 10, cycle: "monthly" }, { price: 120, cycle: "yearly" }]);
  assert.strictEqual(t.monthly, 20);
  assert.strictEqual(t.yearly, 240);
});
