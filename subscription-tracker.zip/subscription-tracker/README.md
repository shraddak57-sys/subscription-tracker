# SubTrack: Subscription Tracker

[![CI](https://github.com/YOUR-USERNAME/subscription-tracker/actions/workflows/ci.yml/badge.svg)](https://github.com/YOUR-USERNAME/subscription-tracker/actions)
![License](https://img.shields.io/badge/license-MIT-green)

**Live demo:** https://YOUR-USERNAME.github.io/subscription-tracker/

## The problem
Small recurring charges add up and are easy to forget. A $9/month service and a $99/year service look nothing alike on a bank statement, but both are ongoing costs. SubTrack puts every subscription in one place, converts them all to a true monthly and yearly cost, and shows what renews next so you can cancel before you're charged.

## Features
- Weekly, monthly, and yearly billing cycles, normalized to monthly and yearly totals
- Renewal dates calculated automatically, including end-of-month edge cases (Jan 31 renews Feb 28)
- Sorted by next renewal, with a highlight for charges due within 7 days
- No account, no server: data stays in your browser's `localStorage`
- Responsive layout and automatic dark mode
- Billing logic isolated from the UI and unit tested

## Run locally
Open `index.html` in a browser. No build step.

## Test
```bash
npm test
```
Requires Node 18+.

## Deploy
Repo **Settings → Pages → Deploy from a branch → `main` / root**.

## Roadmap
- Email or push renewal reminders
- Import subscriptions from a bank CSV
- Multi-currency support
- Export and sync across devices

## License
MIT, see [LICENSE](LICENSE).
