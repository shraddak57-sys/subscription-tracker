(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.Logic = factory();
})(this, function () {
  const pad = (n) => String(n).padStart(2, "0");
  const key = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const parse = (k) => { const [y, m, d] = k.split("-").map(Number); return new Date(y, m - 1, d); };
  const midnight = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const addDays = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
  // Adds months, clamping to the last day (Jan 31 + 1 month = Feb 28/29).
  const addMonths = (d, k) => {
    const m = d.getMonth() + k;
    const last = new Date(d.getFullYear(), m + 1, 0).getDate();
    return new Date(d.getFullYear(), m, Math.min(d.getDate(), last));
  };

  const monthlyCost = (price, cycle) =>
    cycle === "weekly" ? (price * 52) / 12 : cycle === "yearly" ? price / 12 : price;

  // First billing date on or after `today`.
  function nextRenewal(start, cycle, today) {
    const t = midnight(today), s = parse(start);
    if (s >= t) return s;
    if (cycle === "weekly") {
      const weeks = Math.ceil(Math.round((t - s) / 864e5) / 7);
      return addDays(s, weeks * 7);
    }
    const step = cycle === "yearly" ? 12 : 1;
    let k = 0, d = s;
    while (d < t) { k++; d = addMonths(s, k * step); }
    return d;
  }

  const daysUntil = (date, today) => Math.round((midnight(date) - midnight(today)) / 864e5);

  function totals(subs) {
    const monthly = subs.reduce((sum, s) => sum + monthlyCost(s.price, s.cycle), 0);
    return { monthly, yearly: monthly * 12 };
  }

  return { key, parse, addDays, addMonths, monthlyCost, nextRenewal, daysUntil, totals };
});
